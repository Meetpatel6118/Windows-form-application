﻿using System;
using System.Data;

namespace ConsoleApp
{
    class Program
    {
        static void Main(string[] args)
        {
            DataSet EmployeeProjectsDS = new DataSet("EmployeeProjectsDS");
            DataTable Employees = new DataTable("Employees");
            DataTable Projects = new DataTable("Projects");
            DataTable ProjectAssignments = new DataTable("ProjectAssignments");

            EmployeeProjectsDS.Tables.Add(Employees);
            EmployeeProjectsDS.Tables.Add(Projects);
            EmployeeProjectsDS.Tables.Add(ProjectAssignments);

            Employees.Columns.Add("EmployeeId", typeof(int)).AutoIncrement = true;
            Employees.Columns["EmployeeId"].AutoIncrementSeed = 11111;
            Employees.Columns["EmployeeId"].AutoIncrementStep = 11111;
            Employees.PrimaryKey = new DataColumn[] { Employees.Columns["EmployeeId"] };
            Employees.Columns.Add("FirstName", typeof(string));
            Employees.Columns.Add("LastName", typeof(string));
            Employees.Columns.Add("PhoneNumber", typeof(string));
            Employees.Columns.Add("Email", typeof(string));

            Projects.Columns.Add("ProjectCode", typeof(string));
            Projects.PrimaryKey = new DataColumn[] { Projects.Columns["ProjectCode"] };
            Projects.Columns.Add("ProjectTitle", typeof(string));

            ProjectAssignments.Columns.Add("EmployeeId", typeof(int));
            ProjectAssignments.Columns.Add("ProjectCode", typeof(string));
            ProjectAssignments.Columns.Add("StartingDate", typeof(DateTime));
            ProjectAssignments.Columns.Add("EndingDate", typeof(DateTime));
            ProjectAssignments.PrimaryKey = new DataColumn[] { ProjectAssignments.Columns["EmployeeId"], ProjectAssignments.Columns["ProjectCode"] };

            DataRelation relation1 = new DataRelation("Employee_ProjectAssignment", Employees.Columns["EmployeeId"], ProjectAssignments.Columns["EmployeeId"]);
            DataRelation relation2 = new DataRelation("Project_ProjectAssignment", Projects.Columns["ProjectCode"], ProjectAssignments.Columns["ProjectCode"]);
            EmployeeProjectsDS.Relations.Add(relation1);
            EmployeeProjectsDS.Relations.Add(relation2);

            Employees.Rows.Add(null, "Mary", "Brown", "(514)111-1111", "maryBrown@yahoo.com");
            Employees.Rows.Add(null, "John", "Abbott", "(514)222-2222", "johnAbbott@gmail.com");
            Employees.Rows.Add(null, "Thomas", "Moore", "(514)333-3333", "thomasMoore@gmail.com");

            Projects.Rows.Add("PRJ101", "Online Order Management in ASP.Net Core MVC");
            Projects.Rows.Add("PRJ102", "Property Rental Management in Java");
            Projects.Rows.Add("PRJ103", "Online Course Registration in PHP");

            ProjectAssignments.Rows.Add(11111, "PRJ101", new DateTime(2024, 01, 25), new DateTime(2024, 05, 25));
            ProjectAssignments.Rows.Add(11111, "PRJ102", new DateTime(2024, 01, 25), new DateTime(2024, 05, 25));
            ProjectAssignments.Rows.Add(22222, "PRJ101", new DateTime(2024, 01, 25), new DateTime(2024, 05, 25));
            ProjectAssignments.Rows.Add(33333, "PRJ103", new DateTime(2024, 01, 25), new DateTime(2024, 05, 25));
            ProjectAssignments.Rows.Add(33333, "PRJ101", new DateTime(2024, 01, 25), new DateTime(2024, 05, 25));

            Console.WriteLine("Projects assigned to Mary Brown (EmployeeId = 11111):");
            DataRow[] maryProjects = Employees.Select("EmployeeId = 11111")[0].GetChildRows(relation1);
            foreach (DataRow projectRow in maryProjects)
            {
                string projectCode = projectRow["ProjectCode"].ToString();
                string projectTitle = Projects.Select($"ProjectCode = '{projectCode}'")[0]["ProjectTitle"].ToString();
                Console.WriteLine("- " + projectTitle);
            }

            Console.WriteLine("\nEmployees assigned to project PRJ101:");
            DataRow[] prj101Assignments = Projects.Select("ProjectCode = 'PRJ101'")[0].GetChildRows(relation2);
            foreach (DataRow assignmentRow in prj101Assignments)
            {
                int employeeId = Convert.ToInt32(assignmentRow["EmployeeId"]);
                DataRow employeeRow = Employees.Select($"EmployeeId = {employeeId}")[0];
                string firstName = employeeRow["FirstName"].ToString();
                string lastName = employeeRow["LastName"].ToString();
                Console.WriteLine("- " + firstName + " " + lastName);
            }

            Console.ReadLine(); 
        }
    }
}
