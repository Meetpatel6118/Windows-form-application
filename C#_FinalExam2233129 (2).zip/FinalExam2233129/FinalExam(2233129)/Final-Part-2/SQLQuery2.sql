USE TeacherCourseDB;
GO

-- Create Users table
CREATE TABLE Users (
    UserID INT PRIMARY KEY,
    Password NVARCHAR(50),
    JobTitle NVARCHAR(50)
);

-- Populate Users table
INSERT INTO Users (UserID, Password, JobTitle)
VALUES (11111, 'Mary_1234','Teacher'),
       (22222, 'Wei_1235','Teacher'),
       (33333, 'Michael_1236','Teacher'),
       (44444, 'Daniel_1237','Program Coordinator');

-- Create Teachers table
CREATE TABLE Teachers (
    TeacherID INT PRIMARY KEY,
    FirstName NVARCHAR(50),
    LastName NVARCHAR(50),
    Email NVARCHAR(50)
);

-- Populate Teachers table
INSERT INTO Teachers (TeacherID, FirstName, LastName, Email)
VALUES (11111, 'Mary', 'Brown', 'mary@yahoo.com'),
       (22222, 'Wei', 'Huang', 'wei@gmail.com'),
       (33333, 'Michael', 'Freitag', 'michael@hotmail.com'),
       (44444, 'Daniel', 'Rother', 'daniel@yahoo.com');

-- Create Courses table
CREATE TABLE Courses (
    CourseNumber NVARCHAR(50) PRIMARY KEY,
    CourseTitle NVARCHAR(50),
    Duration INT
);
INSERT INTO Courses (CourseNumber, CourseTitle, Duration)
VALUES ('COMP101', 'Structured Programming', 90),
       ('COMP102', 'Introduction to C#', 75),
       ('COMP103', 'Advanced Programming in C#', 75),
       ('COMP104', 'Web Programming I', 90),
       ('COMP105', 'Web Programming II', 90);
CREATE TABLE TeacherCourses (
    TeacherID INT,
    CourseNumber NVARCHAR(50),
    RegistrationDate DATE,
    FOREIGN KEY (TeacherID) REFERENCES Teachers(TeacherID),
    FOREIGN KEY (CourseNumber) REFERENCES Courses(CourseNumber),
    PRIMARY KEY (TeacherID, CourseNumber)
);