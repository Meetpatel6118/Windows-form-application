﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAL;
namespace BILL
{
    internal class TeacherManager
    {
        private readonly DataAccess dataAccess = new DataAccess();

        public DataTable GetAllTeachers()
        {
            string query = "SELECT * FROM Teachers";
            return dataAccess.ExecuteQuery(query);
        }

        public DataTable GetTeacherById(int teacherId)
        {
            string query = $"SELECT * FROM Teachers WHERE teacherID = {teacherId}";
            return dataAccess.ExecuteQuery(query);
        }
    }
}
