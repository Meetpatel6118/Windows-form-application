﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAL;
namespace BILL
{
    internal class UserManager
    {
        private readonly DataAccess dataAccess = new DataAccess();

        public DataTable GetAllUsers()
        {
            string query = "SELECT * FROM Users";
            return dataAccess.ExecuteQuery(query);
        }

        public bool ValidateUser(int userId, string password)
        {
            string query = $"SELECT COUNT(*) FROM Users WHERE UserID = {userId} AND Password = '{password}'";
            int count = (int)dataAccess.ExecuteScalar(query);
            return count > 0;
        }
    }
}
