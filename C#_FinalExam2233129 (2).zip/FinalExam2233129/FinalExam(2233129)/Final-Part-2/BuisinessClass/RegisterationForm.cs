﻿using BILL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BILL;

namespace BuisinessClass
{
    public partial class CourseRegistrationForm : Form
    {
        private readonly TeacherManager teacherManager= new TeacherManager();
        private readonly int tea
        private readonly CourseManager courseManager = new CourseManager();
        private readonly int studentId;
        private int registeredCoursesCount;
        public CourseRegistrationForm()
        {
            InitializeComponent();
            this.studentId = studentId;
            this.registeredCoursesCount = GetRegisteredCoursesCount(studentId);

            LoadCourses();
            LoadRegisteredCourses(studentId);
        }

        private void LoadCourses()
        {
            DataTable courses = courseManager.GetAllCourses();
            cmbCourses.DataSource = courses;
            cmbCourses.DisplayMember = "CourseTitle";
            cmbCourses.ValueMember = "CourseNumber";
        }

        private void LoadRegisteredCourses(int studentId)
        {
            
        }

        private int GetRegisteredCoursesCount(int studentId)
        {
            
            return 0;
        }

        private void btnRegisterCourse_Click(object sender, EventArgs e)
        {
            if (registeredCoursesCount >= 3)
            {
                MessageBox.Show("You cannot register more than 3 courses!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            string courseNumber = cmbCourses.SelectedValue.ToString();

            
            bool isCourseRegistered = false;

            if (isCourseRegistered)
            {
                MessageBox.Show("You have already registered for this course!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

           

            MessageBox.Show("Course registered successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            registeredCoursesCount++;
            LoadRegisteredCourses(studentId);
        }

        private void btnListCourses_Click(object sender, EventArgs e)
        {
            
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are you sure you want to exit?", "Exit Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        private void CourseRegistrationForm_Load(object sender, EventArgs e)
        {

        }

        private void btnRegisterCourse_Click_1(object sender, EventArgs e)
        {

        }
    }
}

        
