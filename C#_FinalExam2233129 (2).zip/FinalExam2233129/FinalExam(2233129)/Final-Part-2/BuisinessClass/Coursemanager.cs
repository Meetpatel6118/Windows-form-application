﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAL;
namespace BILL
{
    internal class Coursemanager
    {
        private readonly DataAccess dataAccess = new DataAccess();

        public DataTable GetAllCourses()
        {
            string query = "SELECT * FROM Courses";
            return dataAccess.ExecuteQuery(query);
        }

        public DataTable GetCourseByNumber(string courseNumber)
        {
            string query = $"SELECT * FROM Courses WHERE CourseNumber = '{courseNumber}'";
            return dataAccess.ExecuteQuery(query);
        }
    }
}

