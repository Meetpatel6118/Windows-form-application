﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BuisinessClass
{
    public partial class LoginForm : Form
    {
        public LoginForm()
        {
            InitializeComponent();
        }

        private void BtnLogin_Click(object sender, EventArgs e)
        {
            int userId;
            if (int.TryParse(txtUserID.Text, out userId))
            {
                
                if (userId == 11111 && txtPassword.Text == "Mary_1234")
                {
                    MessageBox.Show("Login successful!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

                   CourseRegistrationForm registrationForm = new CourseRegistrationForm();

                    registrationForm.Show();
                   
                    this.Hide(); 
                               
                }
                else
                {
                    MessageBox.Show("Invalid UserID or Password!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("Invalid UserID!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void txtUserID_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
