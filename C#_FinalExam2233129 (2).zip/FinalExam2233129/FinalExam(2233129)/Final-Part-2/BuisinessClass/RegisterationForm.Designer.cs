﻿namespace BuisinessClass
{
    partial class CourseRegistrationForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnRegisterCourse = new System.Windows.Forms.Button();
            this.btnListCourses = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.cmbCourses = new System.Windows.Forms.ComboBox();
            this.lstRegisteredCourses = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // btnRegisterCourse
            // 
            this.btnRegisterCourse.Location = new System.Drawing.Point(235, 45);
            this.btnRegisterCourse.Name = "btnRegisterCourse";
            this.btnRegisterCourse.Size = new System.Drawing.Size(122, 55);
            this.btnRegisterCourse.TabIndex = 0;
            this.btnRegisterCourse.Text = "RegisterCourse";
            this.btnRegisterCourse.UseVisualStyleBackColor = true;
            this.btnRegisterCourse.Click += new System.EventHandler(this.btnRegisterCourse_Click_1);
            // 
            // btnListCourses
            // 
            this.btnListCourses.Location = new System.Drawing.Point(235, 117);
            this.btnListCourses.Name = "btnListCourses";
            this.btnListCourses.Size = new System.Drawing.Size(122, 55);
            this.btnListCourses.TabIndex = 1;
            this.btnListCourses.Text = "ListCourses";
            this.btnListCourses.UseVisualStyleBackColor = true;
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(235, 201);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(122, 55);
            this.btnExit.TabIndex = 2;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            // 
            // cmbCourses
            // 
            this.cmbCourses.FormattingEnabled = true;
            this.cmbCourses.Location = new System.Drawing.Point(40, 61);
            this.cmbCourses.Name = "cmbCourses";
            this.cmbCourses.Size = new System.Drawing.Size(121, 24);
            this.cmbCourses.TabIndex = 3;
            // 
            // lstRegisteredCourses
            // 
            this.lstRegisteredCourses.FormattingEnabled = true;
            this.lstRegisteredCourses.ItemHeight = 16;
            this.lstRegisteredCourses.Location = new System.Drawing.Point(40, 117);
            this.lstRegisteredCourses.Name = "lstRegisteredCourses";
            this.lstRegisteredCourses.Size = new System.Drawing.Size(172, 100);
            this.lstRegisteredCourses.TabIndex = 4;
            // 
            // CourseRegistrationForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lstRegisteredCourses);
            this.Controls.Add(this.cmbCourses);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnListCourses);
            this.Controls.Add(this.btnRegisterCourse);
            this.Name = "CourseRegistrationForm";
            this.Text = "CourseRegistrationForm";
            this.Load += new System.EventHandler(this.CourseRegistrationForm_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnRegisterCourse;
        private System.Windows.Forms.Button btnListCourses;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.ComboBox cmbCourses;
        private System.Windows.Forms.ListBox lstRegisteredCourses;
    }
}

